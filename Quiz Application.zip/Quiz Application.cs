﻿using System;

class Program
{
    static void Main(string[] args)
    {
        // Questions
        string[] questions =
        {
            "What is an Abstract class in C#?",
            "What is an Interface in C#?",
            "What is Polymorphism in C#?",
            "What is Inheritance in C#?"
        };

        // Options
        string[,] options =
        {
            { "A class that cannot be instantiated", "A variable type", "A loop", "A method" },
            { "A class with implementation", "A contract with method declarations", "A data type", "A namespace" },
            { "Using multiple classes", "Ability of object to take many forms", "Code repetition", "Using loops" },
            { "Copying code", "Using interfaces", "One class acquiring properties of another", "Using objects" }
        };

        // Correct answers (1-based index)
        int[] answers = { 1, 2, 2, 3 };

        int score = 0;

        Console.WriteLine("=== OOP QUIZ APPLICATION ===\n");

        for (int i = 0; i < questions.Length; i++)
        {
            Console.WriteLine("Q" + (i + 1) + ": " + questions[i]);

            for (int j = 0; j < 4; j++)
            {
                Console.WriteLine((j + 1) + ". " + options[i, j]);
            }

            Console.Write("Enter your answer (1-4): ");
            int userAnswer = Convert.ToInt32(Console.ReadLine());

            if (userAnswer == answers[i])
            {
                Console.WriteLine("Correct!\n");
                score++;
            }
            else
            {
                Console.WriteLine("Wrong!\n");
            }
        }

        Console.WriteLine("Quiz Finished!");
        Console.WriteLine("Your Score: " + score + " / " + questions.Length);

        Console.ReadLine();
    }
}
